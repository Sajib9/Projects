-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2017 at 05:21 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carrental`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcar`
--

CREATE TABLE `addcar` (
  `car_id` int(11) NOT NULL,
  `model` varchar(20) NOT NULL,
  `seat` int(11) NOT NULL,
  `condition` varchar(50) NOT NULL,
  `laugage` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rent_price` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addcar`
--

INSERT INTO `addcar` (`car_id`, `model`, `seat`, `condition`, `laugage`, `quantity`, `rent_price`) VALUES
(2, 'Corolla 2017', 4, 'yes', 5, 0, '2000 tk'),
(3, 'BMW', 4, 'yes', 3, 8, '5000'),
(4, 'Toyota', 4, 'No', 2, 10, '2500'),
(5, 'Nissan', 4, 'Yes', 4, 8, '1800'),
(6, 'Haice', 9, 'Yes', 3, 15, '4000');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Card_id` int(15) NOT NULL,
  `username` varchar(250) NOT NULL,
  `model` varchar(250) NOT NULL,
  `seat` int(15) NOT NULL,
  `aircondition` varchar(250) NOT NULL,
  `rent_price` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`Card_id`, `username`, `model`, `seat`, `aircondition`, `rent_price`) VALUES
(1, 'shakil@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(2, 'shakil@gmail.com', 'BMW', 4, 'yes', '5000'),
(3, 'shakil@gmail.com', 'Toyota', 4, 'No', '2500'),
(4, 'shakil@gmail.com', 'Toyota', 4, 'No', '2500'),
(5, 'shakil@gmail.com', 'Toyota', 4, 'No', '2500'),
(6, 'mahbub@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(7, 'mahbub@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(8, 'mahbub@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(9, 'mahbub@gmail.com', 'BMW', 4, 'yes', '5000'),
(10, 'mahbub@gmail.com', 'Toyota', 4, 'No', '2500'),
(11, 'mahbub@gmail.com', 'Toyota', 4, 'No', '2500'),
(12, 'jahanahmed@gmail.com', 'BMW', 4, 'yes', '5000'),
(13, 'jahanahmed@gmail.com', 'BMW', 4, 'yes', '5000'),
(14, 'jahanahmed@gmail.com', 'Toyota', 4, 'No', '2500'),
(15, 'srijon@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(16, 'srijon@gmail.com', 'BMW', 4, 'yes', '5000'),
(17, 'srijon@gmail.com', 'Toyota', 4, 'No', '2500'),
(18, 'misrat@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(19, 'misrat@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(20, 'misrat@gmail.com', 'Haice', 9, 'Yes', '4000'),
(21, 'misrat@gmail.com', 'Nissan', 4, 'Yes', '1800'),
(22, 'misrat@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(23, 'misrat@gmail.com', 'Corolla 2017', 4, 'yes', '2000 tk'),
(24, 'misrat@gmail.com', 'Haice', 9, 'Yes', '4000');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `fullname` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `district` varchar(10) NOT NULL,
  `houseno` varchar(10) NOT NULL,
  `phone` int(11) NOT NULL,
  `type` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fullname`, `email`, `password`, `district`, `houseno`, `phone`, `type`) VALUES
(1, 'Jahan Ahmed', 'jahanahmed@gmail.com', '12', 'Dhaka', '12', 1728980842, 'user'),
(3, 'Mahbub', 'mahbub@gmail.com', '12345678', 'Dhaka', '306', 1673595182, 'user'),
(4, 'Srijon', 'srijon@gmail.com', '123456789', 'Dhaka', '206', 1673564655, 'user'),
(5, 'Shakil', 'shakil@gmail.com', 'shakil123', 'Khulna', '306', 1912948903, 'user'),
(6, 'Sujon', 'sujon@gmail.com', 'sujon123', 'khulna', '205', 194856565, 'user'),
(7, 'admin', 'admin@gmail.com', 'admin123', '', '', 0, 'admin'),
(8, 'Misrat', 'misrat@gmail.com', 'misrat123', 'Chittagong', '36', 198754565, 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addcar`
--
ALTER TABLE `addcar`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Card_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addcar`
--
ALTER TABLE `addcar`
  MODIFY `car_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `Card_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
