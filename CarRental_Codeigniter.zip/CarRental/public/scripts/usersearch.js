function UserloadCar()
{
	var search = $('#search').val();
	
	$.ajax({
		type: "post",
		url: 'http://localhost/CarRental/userhome/getCar',
		data: {did: search},
		success: function(result){
			$('#results').html(result);
		}
	});
}

