function fnameCheck()
{
		var fname = $("#fname").val();
		var fnamematch = /^[a-zA-Z]{3,}$/;
						
		if(fname.length > 0)
		{
			if(fname.match(fnamematch))
			{
				$("#fnameErr").html("");
			}
			else
			{
				$("#fnameErr").html("Minimum 3 letters are required");
			}
		}
		else
		{
			$("#fnameErr").html("The Firstname field is required");
		}
}

function lnameCheck()
{
		var lname = $("#lname").val();
		var lnamematch = /^[a-zA-Z]{3,}$/;
						
		if(lname.length > 0)
		{
			if(lname.match(lnamematch))
			{
				$("#lnameErr").html("");
			}
			else
			{
				$("#lnameErr").html("Minimum 3 letters are required");
			}
		}
		else
		{
			$("#lnameErr").html("The Lastname field is required");
		}
}

function addressCheck()
{
		var address = $("#address").val();
						
		if(address.length > 0)
		{
			$("#addressErr").html("");
			
		}
		else
		{
			$("#addressErr").html("The Address field is required");
		}
}

function emailCheck()
{
		var email = $("#email").val();
						
		if(email.length > 0)
		{
			var atpos = email.indexOf("@");
			var dotpos = email.lastIndexOf(".");
							
			if(atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length)
			{
				$("#emailErr").html("Not a valid email address");
			}
			else
				$("#emailErr").html("");
		}
		else
		{
			$("#emailErr").html("The Email field is required");
		}
}

function phoneCheck()
{
		var phone = $("#phone").val();
		var phonematch = /^[0-9]\d{10}$/; 
						
		if(phone.length > 0)
		{
			if(phone.match(	phonematch))
			{
				$("#phoneErr").html("");
			}
			else
			{
				$("#phoneErr").html("11 digits are required");
			}
						
							
		}
		else
		{
			$("#phoneErr").html("The Phone field is required");
		}
}

function passCheck()
{
		var pass = $("#pass").val();
		var passmatch = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
		 
						
		if(pass.length > 0)
		{
			
			if(pass.match(passmatch))
			{
				$("#passwordErr").html("");
			}
			else
			{
				$("#passwordErr").html("Minimum 8 characters are required<br />Password must have at least one Uppercase,<br />one lowercase,one special character and one digit");
			}
		}
		else
		{
			$("#passwordErr").html("The Password field is required");
		}
}

function conpassCheck()
{
		var conpass = $("#conpass").val();
		var pass = $("#pass").val();
							
		if(conpass.length > 0)
		{
			if(pass == conpass)
				$("#conpassErr").html("Matched");
			else
			{
				$("#conpassErr").html("Password didn't matched");
			}
		}
		else
		{
			$("#conpassErr").html("The ConfirmPassword field is required");
		}
}


function check()
{
	
	var fname = $("#fname").val();
	var lname = $("#lname").val();
	var phone = $("#phone").val();
	var email =$("#email").val();
	var address =$("#address").val();
	var pass = $("#pass").val();
	var conpass = $("#conpass").val();
	var flag = true;
	var lang = $("#lang").is(":checked");
	var lang2 = $("#langb").is(":checked");
	
	if(lang || lang2)
	{
		$("#langErr").html("");
		
	}
	else
	{
		$("#langErr").html("Language field is required");
	}

	
						
	if(fname == null || fname == "" || lname == null || lname == "" || phone == null || phone == "" || email == null || email == "" ||  pass == null || pass == "" || conpass == null || conpass == "")
	{
		if(fname.length < 1)
			$("#fnameErr").html("First name is required");
		if(lname.length < 1)
			$("#lnameErr").html("Last name is required");
		if(phone.length < 1)
			$("#phoneErr").html("Phone No. is required");
		if(email.length < 1)
			$("#emailErr").html("Email is required");
		if(address.length < 1)
			$("#addressErr").html("Address is required");
		if(pass.length < 1)
			$("#passwordErr").html("Password is required");
		if(conpass.length < 1)
			$("#conpassErr").html("Confirm Password is required");
		
		flag = false;
	}
	else
	{
		
		var fnamematch = /^[a-zA-Z]{3,}$/;
		var lnamematch = /^[a-zA-Z]{3,}$/;
		var atpos = email.indexOf("@");
		var dotpos = email.lastIndexOf(".");
		var phonematch = /^[0-9]\d{10}$/; 
		var passmatch = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
		if(fname.match(fnamematch))
		{
			$("#fnameErr").html("");
		}
		else
		{
			$("#fnameErr").html("Minimum 3 letters are required");
			flag = false;
		}
		
		if(lname.match(lnamematch))
		{
			$("#lnameErr").html("");
		}
		else
		{
			$("#lnameErr").html("Minimum 3 letters are required");
			flag = false;
		}
							
		if(atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length)
		{
			$("#emailErr").html("Not a valid email address");
			flag = false;
		}
		else
		{
			$("#emailErr").html("");
		}
		
		if(phone.match(	phonematch))
		{
			$("#phoneErr").html("");
		}
		else
		{
			$("#phoneErr").html("11 digits are required");
			flag = false;
		}
		
		if(pass.match(passmatch))
		{
			$("#passwordErr").html("");
		}
		else
		{
			$("#passwordErr").html("Minimum 8 characters are required<br />Password must have at least one Uppercase,<br />one lowercase,one special character and one digit");
			flag = false;
		}
		
		if(pass == conpass)
		{
			$("#conpassErr").html("Matched");
		}
		else
		{
			$("#conpassErr").html("Password didn't matched");
			flag = false;
		}
		
		if(lang || lang2)
		{
			$("#langErr").html("");
		
		}
		else
		{
			$("#langErr").html("Language field is required");
			flag = false;
		}
		
		
		
	}
	
	
	
	return flag;
}


					
					

