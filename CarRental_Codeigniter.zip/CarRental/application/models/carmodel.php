<?php

/**
 * Created by PhpStorm.
 * User: MahbubHabib
 * Date: 14-03-17
 * Time: 06.43
 */
class carmodel extends CI_Model
{
    public function selectCar($model)
    {
        $this->db->select("*");
        $this->db->where("model",$model);


        $result = $this->db->get("addcar");
        return $result->result_array();
    }
	
	public function findCar($model)
    {
        $this->db->where("model",$model);


        $result = $this->db->get("addcar");
        return $result->row_array();
    }
	
	public function addCart($car,$user)
	{
		$model = $this->findCar($car);
		
		if($model["quantity"] > 0)
		{
		
			$param = array(
				"username" => $user,
				"model" => $model['model'],
				"seat" => $model['seat'],
				"aircondition" => $model['condition'],
				"rent_price" => $model['rent_price']
			);
				$this->db->insert("cart",$param);
				$quan = (int)$model["quantity"] - 1;
				$sql = "UPDATE addcar SET quantity=$quan WHERE model='$car'";
				$this->db->query($sql);
		}
		
		
	}
	
	public function getbestcar()
	{
			$sql = "SELECT model, SUM(rent_price) as price from cart GROUP BY model ORDER BY price desc";

			$result= $this->db->query($sql);

			return $result->result_array();

	}
	
	public function getbestuser()
	{
			$sql = "SELECT username, SUM(rent_price) as price from cart GROUP BY username ORDER BY price desc";

			$result= $this->db->query($sql);

			return $result->result_array();

	}
	public function viewcart($user)
	{
		$this->db->where("username",$user);
		$result = $this->db->get("cart");
		return $result->result_array();
	}
}