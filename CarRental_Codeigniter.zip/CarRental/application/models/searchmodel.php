<?php

/**
 * Created by PhpStorm.
 * User: MahbubHabib
 * Date: 14-03-17
 * Time: 06.57
 */
class searchmodel extends CI_Model
{
    public function getCarlist($car)
    {
        $this->db->like('model', $car);
        $result = $this->db->get('addcar');
        return $result->result_array();

    }
}