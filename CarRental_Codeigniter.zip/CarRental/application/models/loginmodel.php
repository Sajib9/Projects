<?php

class LoginModel extends CI_Model{

    //---------------Admin login----------------
    public function verifyAdmin($email,$password)
    {
        $this->db->where("Email",$email);
        $this->db->where("Password",$password);
        $this->db->where("type","admin");
        $result = $this->db->get("users");

        $row = $result->row_array();

        if($row)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //--------------User Login-------------
    public function verifyUser($email,$password)
    {

        $this->db->where("Email",$email);
        $this->db->where("Password",$password);
        $this->db->where("type","user");
        $result = $this->db->get("users");

        $row = $result->row_array();

        if($row)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //-------------------------registration--------------

    public function addUser($fullname,$email,$password,$district,$houseno,$phone){

        $sql = "INSERT INTO users VALUES (null, '$fullname','$email','$password','$district','$houseno','$phone','user')";
        $this->db->query($sql);
    }

    public function findUser($username)
    {
        $this->db->select("*");
        $this->db->where("email",$username);
        $result = $this->db->get("users");

        return $result->row_array();
    }

    public function getCarList()
    {
        $sql = "SELECT * FROM addcar";
        $result = $this->db->query($sql);

        return $result->result_array();
    }
}