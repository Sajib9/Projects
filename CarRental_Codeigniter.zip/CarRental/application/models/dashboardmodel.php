<?php

class Dashboardmodel extends CI_Model{

    //-------------------------registration--------------

    public function addCar($model,$seat,$condition,$laugage,$quantity,$rentprice){

        $sql = "INSERT INTO addcar VALUES (null, '$model','$seat','$condition','$laugage','$quantity','$rentprice')";
        $this->db->query($sql);
    }

    public function getUserList()
    {
        $sql = "SELECT * FROM users";
        $result = $this->db->query($sql);

        return $result->result_array();
    }


    public function getUser($username)
    {
        $this->db->select("*");
        $this->db->where("Email",$username);
        $result = $this->db->get("users");

        return $result->row_array();
    }
}