<?php

/**
 * Created by PhpStorm.
 * User: MahbubHabib
 * Date: 14-03-17
 * Time: 08.05
 */
class usermodel extends CI_Model
{
    public function getCarList()
    {
        $sql = "SELECT * FROM addcar";
        $result = $this->db->query($sql);

        return $result->result_array();
    }

    public function getCar($carmodel)
    {
        $this->db->where("model",$carmodel);
        $result = $this->db->get("addcar");

        return $result->row_array();
    }

    public function getUser($username)
    {
        $this->db->select("*");
        $this->db->where("email",$username);
        $result = $this->db->get("users");

        return $result->row_array();
    }

    public function updateUser($fname,$email,$phone,$district,$pass)
    {
        $sql = "UPDATE users SET fullname='$fname',Phone='$phone',district='$district',password='$pass' WHERE email='$email'";

        $this->db->query($sql);
    }

}