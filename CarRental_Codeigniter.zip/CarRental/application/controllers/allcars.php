<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class allcars extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('loginmodel');
        $this->load->database();
    }


    public function index()
    {
        $data['carlist'] = $this->loginmodel->getCarList();
        $this->load->view('view_allcars', $data);
    }

}