<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Userhome extends CI_Controller {


    public function __construct()
    {

        parent::__construct();
        if(! $this->session->userdata('username'))
        {
            $this->load->helper('url');
            redirect('http://localhost/CarRental/login', 'refresh');
            return;
        }

        $this->load->model('usermodel');
        $this->load->library("form_validation");
        $this->load->model("carmodel");
        $this->load->model("searchmodel");
        $this->load->database();
    }


    //-----------------All Book Home------------

    public function Uhome()
    {
        $data['carlist'] = $this->usermodel->getCarList();
        $this->load->view('view_user_home',$data);
    }

    //----------search--------------------

    public function searchCar()
    {
		$this->load->view("view_user_search");


    }
	
	public function addCart($car)
	{
		$car = urldecode($car);
		$user = $this->session->userdata("username");
		$this->carmodel->addCart($car,$user);
		$data["carlist"] = $this->carmodel->viewcart($user);
		$this->load->view("view_user_cart",$data);
	}


    //----------Cart--------------------

    public function cart()
    {
		$user = $this->session->userdata("username");
		$data["carlist"] = $this->carmodel->viewcart($user);
		$this->load->view("view_user_cart",$data);

    }

    //----------Profile--------------------

    public function profile()
    {
        $user = $this->session->userdata("username");
        $data["user"] = $this->usermodel->getUser($user);

        $this->form_validation->set_rules("fname","Fullname","trim|required|min_length[3]");
        $this->form_validation->set_rules("phone","Phone","trim|required|numeric|max_length[11]");
        $this->form_validation->set_rules("district","Address","trim|required");
        $this->form_validation->set_rules("pass","Password","trim|required|min_length[8]|callback_passCheck[pass]");
        $this->form_validation->set_rules("conpass","Confirm Password","trim|required|matches[pass]");


        if($this->form_validation->run() == false)
        {

            $data["msg"] = "";
            $this->parser->parse("view_user_profile",$data);

        }
        else {
            $fname = $this->input->post("fname");
            $email = $this->input->post("email");
            $phone = $this->input->post("phone");
            $address = $this->input->post("district");
            $pass = $this->input->post("pass");

            $this->usermodel->updateUser($fname, $user, $phone, $address, $pass);
            $data["user"] = $this->usermodel->getUser($user);
            $data["msg"] = "Updated successfully";
            $this->parser->parse("view_user_profile", $data);
        }
    }

    public function getCar()
    {
        $car = $this->input->post("did");
        $data = $this->searchmodel->getCarlist($car);
        $outputstr = "";

        echo "<table border = 1 cellpadding = 30 cellspacing = 30>";
        foreach ($data as $car) {
            $outputstr .= "<tr><td><a href = 'http://localhost/CarRental/Userhome/viewCar/$car[model]'>$car[model]</a></td></tr>";

        }

        echo "<table>";
        echo $outputstr;

    }

    public function viewCar($model)
    {
        $model = urldecode($model);
        $data = $this->carmodel->findCar($model);
        $this->load->view("view_carinfo",$data);
    }

    //----------Logout--------------------

    public function logout()
    {
        $this->session->unset_userdata('username');
        $this->load->helper('url');
        redirect('http://localhost/CarRental/login', 'refresh');
    }



}