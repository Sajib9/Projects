<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model("searchmodel");
        $this->load->model("carmodel");
    }

    public function index()
    {
        $data["carlist"] = "";
        $this->load->view("view_home", $data);
    }

    public function getCar()
    {
        $car = $this->input->post("did");
        $data = $this->searchmodel->getCarlist($car);
        $outputstr = "";

        echo "<table border = 1 cellpadding = 30 cellspacing = 30>";
        foreach ($data as $car) {
            $outputstr .= "<tr><td><a href = 'http://localhost/CarRental/home/viewCar/$car[model]'>$car[model]</a></td></tr>";

        }

        echo "<table>";
        echo $outputstr;

    }
	
	public function viewCar($model)
	{
		$model = urldecode($model);
		$data = $this->carmodel->findCar($model);
		$this->load->view("view_search",$data);
	}
	
	
}