<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

/*    public function __construct()
    {
        parent::__construct();
        $this->load->library("session");

        if($this->session->userdata("username"))
        {
            redirect("http://localhost/CarRental/Userhome/Uhome");
            return;
        }
        if($this->session->userdata("admin"))
        {
            redirect("http://localhost/CarRental/dashboard/dhome");
            return;
        }
        $this->load->model("loginmodel");
        $this->load->helper("url");


    }*/
    public function index()
    {
        if($this->input->post('buttonLogin'))
        {
            $el = $this->input->post('email');
            $ps = $this->input->post('password');

            $this->load->model('loginmodel');



            if($this->loginmodel->verifyAdmin($el, $ps))
            {

                $this->session->set_userdata('admin', $el);
                $this->load->helper('url');
                redirect('http://localhost/CarRental/dashboard/dhome', 'refresh');


            }
            else
            {
                echo "Error";
            }

            if($this->loginmodel->verifyUser($el, $ps))
            {

                $this->session->set_userdata('username', $el);

                $this->load->helper('url');
                redirect('http://localhost/CarRental/Userhome/Uhome', 'refresh');

            }
            else
            {
                echo "Error";
            }
        }
        else
        {
            $this->load->view('view_login');
        }
    }

}