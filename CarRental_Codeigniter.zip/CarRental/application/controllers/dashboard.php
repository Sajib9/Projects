<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {


    public function __construct()
    {

        parent::__construct();
        if(! $this->session->userdata('admin'))
        {
            $this->load->helper('url');
            redirect('http://localhost/CarRental/login', 'refresh');
            return;
        }

        $this->load->model('loginmodel');
        $this->load->model('dashboardmodel');
        $this->load->model('carmodel');
        $this->load->library('form_validation');
        $this->load->database();
    }


    //-----------------Dashboard Home ADD CAR------------

    public function dhome()
    {
        $this->form_validation->set_rules("model","Model name","required");
        $this->form_validation->set_rules("seat", "seat number", "required");
        $this->form_validation->set_rules('laugage', 'laugage number', 'required');
        $this->form_validation->set_rules('quantity', 'Quantity number', 'required]');
        $this->form_validation->set_rules("rentprice","rent price(taka)","required");
        //$this->form_validation->set_rules("cimage","car image","required");



        if($this->form_validation->run() == false)
        {

            $admin = $this->session->userdata("admin");
            $data = $this->dashboardmodel->getUser($admin);
            $this->parser->parse('view_dashboard_home',$data);
        }
        else
        {
            if($this->input->post('buttonCar')) {

/*                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('cimage')) {
                    $this->session->set_flashdata('message', $this->upload->display_errors());
                    return;
                } else {
                    $cimage = $this->upload->data();
                    $carimage = $cimage['file_name'];
                }*/

                $model = $this->input->post("model");
                $seat = $this->input->post("seat");
                $condition = $this->input->post("condition");
                $laugage = $this->input->post("laugage");
                $quantity = $this->input->post("quantity");
                $rentprice = $this->input->post("rentprice");

                $this->dashboardmodel->addCar($model, $seat,$condition, $laugage,$quantity, $rentprice);
                $this->load->helper('url');
                redirect('http://localhost/CarRental/dashboard/dhome', 'refresh');

            }
        }
    }

    //----------UserList--------------------

    public function userlist()
    {
        $data['userlist'] = $this->dashboardmodel->getUserList();
        $this->load->view('view_dashboard_userlist', $data);
    }

    //----------Booking--------------------

    public function booking()
    {
        $this->load->view('view_dashboard_booking');
    }

    //----------Report--------------------

    public function report()
    {
		$data["carlist"] = $this->carmodel->getbestcar();
		$data["userlist"] = $this->carmodel->getbestuser(); 
        $this->load->view('view_dashboard_report',$data);
    }

    //----------Logout--------------------

    public function logout()
    {
        $this->session->unset_userdata('admin');
        $this->load->helper('url');
        redirect('http://localhost/CarRental/login', 'refresh');
    }



}