<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Registration extends CI_Controller {

    public function __construct()
    {
        parent:: __construct();
        $this->load->library('form_validation');
        $this->load->model("loginmodel");
        $this->load->database();


    }

    public function index()
    {

        $this->form_validation->set_rules("fullname","FULLNAME","trim|required|min_length[5]|max_length[12]");
        $this->form_validation->set_rules("email", "EMAIL", "required|valid_email|is_unique[users.email]");
        $this->form_validation->set_rules('password', 'PASSWORD', 'trim|required|min_length[8]');
        $this->form_validation->set_rules('confirmpassword', 'Password Confirmation', 'trim|required|matches[password]');
        $this->form_validation->set_rules("district","DISTRICT","required");
        $this->form_validation->set_rules("houseno","HOUSE NO/VILLAGE","required");
        $this->form_validation->set_rules("phone","PHONE NUMBER","required");



        if($this->form_validation->run() == false)
        {

            $this->load->view('view_registration');
        }
        else
        {
            if($this->input->post('submit')) {
                $fullname = $this->input->post("fullname");
                $email = $this->input->post("email");
                $password = $this->input->post("password");
                $district = $this->input->post("district");
                $houseno = $this->input->post("houseno");
                $phone = $this->input->post("phone");

                $this->loginmodel->addUser($fullname, $email, $password,$district, $houseno , $phone);
                $this->load->helper('url');
                redirect('http://localhost/CarRental/login', 'refresh');

            }
        }
    }

}