<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }

        .error
        {
            color: #CC0000;
        }
    </style>
	<script src="http://localhost/carRental/public/scripts/jquery-3.1.1.js" type="text/javascript"></script>
	<script src="http://localhost/carRental/public/scripts/search.js" type="text/javascript"></script>
</head>
<body>
<center>
    <h2>USER HOME</h2>
		<center>
    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental/Userhome/Uhome">All Cars</a></td>
            <td><a href="http://localhost/CarRental/Userhome/searchCar">Search Car</a></td>
            <td><a href="http://localhost/CarRental/Userhome/cart">Your Cart</a></td>
            <td><a href="http://localhost/CarRental/Userhome/profile">Edit Profile</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/dashboard/logout">Logout</a></td>
        </tr>
    </table>

    <br />
    <br />

    <h3>SEARCH</h3>

    <p>
    <table border = "0" cellpadding = "5" cellspacing = "5">
        <form method = "post">
            <tr>
                <td>Search: (Enter a car model to search)</td>
                <td><input onkeyup = "UserloadCar()" type = "text" id = "search" name ="search"></td>
            </tr>


        </form>
    </table>

    <table border = "0" cellpadding = "10" cellspacing = "10">
        <tr>
            <th>Car model</th>
        </tr>



    </table>



    <div id = "results"></div>


    </span>
    </table>
    </p>
	
	
	</center>


</center>
</body>
</html>