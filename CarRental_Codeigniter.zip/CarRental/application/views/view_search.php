<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }
    </style>
</head>
<body>
<center>
    <h2>Car Rental BD</h2>
    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental">Home</a></td>
            <td><a href="http://localhost/CarRental/allcars">All Cars</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/registration">Registration</a></td>
            <td><a href="http://localhost/CarRental/login">Login</a></td>
        </tr>
    </table>

    <br />
    <br />

    <h2>Car Info</h2>
    <center>
        <table border="1" cellpadding="4" cellspacing="4" width="50%">
            <thead>
            <tr>
                <td>Car Image</td>
                <td>Rent price(tk)</td>
                <td>Model</td>
                <td>Seat</td>
                <td>Laugage</td>
                <td>Air-Condition</td>
                <td>Quantity</td>
            </tr>
            </thead>
            <tbody>

            <tr>
                <td><img src="corolla.jpg" height="20%" width="80%"></td>

                <td><?php echo $rent_price; ?></td>
                <td><?php echo $model; ?></td>
                <td><?php echo $seat; ?></td>
                <td><?php echo $laugage; ?></td>
                <td><?php echo $condition; ?></td>
                <td><?php echo $quantity; ?></td>

            </tr>
            </tbody>
        </table>

</center>
</body>
</html>