<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }
    </style>
	<script src="http://localhost/carRental/public/scripts/jquery-3.1.1.js" type="text/javascript"></script>
	<script src="http://localhost/carRental/public/scripts/search.js" type="text/javascript"></script>
</head>
<body>
<center>
    <h2>Car Rental BD</h2>
    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental">Home</a></td>
            <td><a href="http://localhost/CarRental/allcars">All Cars</a></td>
            <td><a href="http://localhost/CarRental/registration">Registration</a></td>
            <td><a href="http://localhost/CarRental/login">Login</a></td>
        </tr>
    </table>

    <br />
    <br />
<!--
    <h3>CAR RESERVATION</h3>
    <table border="1" cellpadding="4" cellspacing="4" width="50%">
        <tbody>
        <tr>
            <td colspan="3" align="center"><select name=""cartype>
                    <option>Select Your Car Type</option>
                    <option>Corolla</option>
                    <option>Toyota</option>
                    <option>BMW</option>
                </select></td>
        </tr>
        <tr >
            <td>Pick up: </td>
            <td colspan="2"><input type="text" name="pickcity" placeholder="Enter a city"></td>
        </tr>
        <tr>
            <td>Drop-off: </td>
            <td colspan="2"><input type="text" name="dropcity" placeholder="Enter a city"></td>
        </tr>
        <tr>
            <td>Pick up(date): </td>
            <td><input type="date" name="pickdate" placeholder="Enter a date"></td>
            <td><input type="text" name="picktime" placeholder="Enter a time"></td>
        </tr>
        <tr>
            <td>Drop-off(date): </td>
            <td><input type="date" name="dropdate" placeholder="Enter a date"></td>
            <td><input type="text" name="picktime" placeholder="Enter a time"></td>
        </tr>
        <tr>
            <td colspan="3" align="center"><input type="submit" name="submit" value="Continue Car Reservation"></td>
        </tr>

        </tbody>
    </table>-->

    <p>
    <table border = "0" cellpadding = "5" cellspacing = "5">
        <form method = "post">
            <tr>
                <td>Search: (Enter a car model to search)</td>
                <td><input onkeyup = "loadCar()" type = "text" id = "search" name ="search"></td>
            </tr>


        </form>
    </table>

    <table border = "0" cellpadding = "10" cellspacing = "10">
        <tr>
            <th>Car model</th>
        </tr>



    </table>



    <div id = "results"></div>


    </span>
    </table>
    </p>


</center>
</body>
</html>