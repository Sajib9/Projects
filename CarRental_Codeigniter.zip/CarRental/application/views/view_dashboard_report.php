<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }

        .error
        {
            color: #CC0000;
        }
    </style>
</head>
<body>
<center>
    <h2>DashBoard(admin)</h2>
    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental/dashboard/dhome">DHome</a></td>
            <td><a href="http://localhost/CarRental/dashboard/booking">Booking</a></td>
            <td><a href="http://localhost/CarRental/dashboard/userlist">Userlist</a></td>
            <td><a href="http://localhost/CarRental/dashboard/report">Report</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/dashboard/logout">Logout</a></td>
        </tr>
    </table>

    <br />
    <br />

    <h1>REPORT TABLE</h1>
	
	<h3>Best Car</h3>
	<?php $count = 0;?>
	<table border = "1" width="600"  cellpadding="4" cellspacing="0">
		<thead>
			
				<tr>
					<th>No.</th>
					 <th>Car Model</th>
					 <th>Rent Price</th>
				</tr>
		</thead>
		<tbody>
		<?php foreach($carlist as $car) { ?>
			<tr>
				<td><?php echo $count = $count + 1; ?></td>
				<td><?php echo $car["model"]; ?></td>
				<td><?php echo $car["price"]; ?></td>
				
			</tr>
		<?php } ?>
		</tbody>
			
		</table>
		
		<h3>Best User</h3>
		<?php $count = 0; ?>
	<table border = "1" width="600"  cellpadding="4" cellspacing="0">
		<thead>
			
				<tr>
					<th>No.</th>
					 <th>UserName</th>
					 <th>Price</th>
				</tr>
		</thead>
		<tbody>
		<?php foreach($userlist as $user) { ?>
			<tr>
				<td><?php echo $count = $count + 1; ?></td>
				<td><?php echo $user["username"]; ?></td>
				<td><?php echo $user["price"]; ?></td>
			</tr>
		<?php } ?>
		</tbody>
			
		</table>


</center>
</body>
</html>