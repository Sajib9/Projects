<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }

        .error
        {
            color: #CC0000;
        }
    </style>
</head>
<body>
<center>
    <h2>USER HOME</h2>

    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental/Userhome/Uhome">All Cars</a></td>
            <td><a href="http://localhost/CarRental/Userhome/searchCar">Search Car</a></td>
            <td><a href="http://localhost/CarRental/Userhome/cart">Your Cart</a></td>
            <td><a href="http://localhost/CarRental/Userhome/profile">Edit Profile</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/dashboard/logout">Logout</a></td>
        </tr>
    </table>

    <br />
    <br />

    <h3>Registration Form</h3>
    <span class = "msg">
				<?php echo validation_errors(); ?>
        <h3>{msg}</h3>
			</span>
    <form method = "post">
        <table cellpadding = "5" cellspacing = "5">
            <tr>
                <td>Firstname:</td>
                <td><input type="text" name="fname" value = "<?php echo $user["fullname"]; ?>" size = "30"/></td>
            </tr>
            <tr>
                <td>Phone:</td>
                <td><input type="text" name="phone" value = "<?php echo $user["phone"]; ?>" size = "30"/></td>
            </tr>
            <tr>
                <td>Address:</td>
                <td><textarea name = "district" rows = "3" cols = "30" ><?php echo $user["district"]; ?></textarea></td>
            </tr>
            <tr>
                <td>Password:</td>
                <td><input type="password" name="pass" size = "30" value = "<?php echo $user["password"]; ?>"/></td>
            </tr>
            <tr>
                <td>Confirm Password:</td>
                <td><input type="password" name="conpass" size = "30" value = "<?php echo $user["password"]; ?>"/></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" name="Submit" value = "Submit"></td>
            </tr>
        </table>
    </form>

</center>
</body>
</html>