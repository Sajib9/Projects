<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }

        .error
        {
            color: #CC0000;
        }
    </style>
</head>
<body>
<center>
    <h2>DashBoard(admin)</h2>

    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental/dashboard/dhome">DHome</a></td>
            <td><a href="http://localhost/CarRental/dashboard/booking">Booking</a></td>
            <td><a href="http://localhost/CarRental/dashboard/userlist">Userlist</a></td>
            <td><a href="http://localhost/CarRental/dashboard/report">Report</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/dashboard/logout">Logout</a></td>
        </tr>
    </table>

    <br />
    <br />

    <h3>ADD CAR</h3>
    <form action="http://localhost/CarRental/dashboard/dhome" method="post">
        <table cellpadding="4" cellspacing="4">
            <tr>
                <td>Model: </td>
                <td><input type="text" name="model" placeholder="Enter your car model" /></td>
                
            </tr>

            <tr>
                <td>Seat: </td>
                <td><input type="text" name="seat" placeholder="Enter car seat no" /></td>
                <td><?php echo form_error('seat', '<p class="error">', '</p>'); ?></td>
            </tr>

            <tr>
                <td>Air-condition: </td>
                <td><select name="condition">
                        <option>Yes</option>
                        <option>No</option>
                    </select></td>

            </tr>

            <tr>
                <td>Laugage: </td>
                <td><input type="text" name="laugage" placeholder="Enter laugage no"/></td>
                <td><?php echo form_error('laugage', '<p class="error">', '</p>'); ?></td>
            </tr>


            <tr>
                <td>Quantity: </td>
                <td><input type="text" name="quantity" placeholder="Enter your quantity no"/></td>
                <td><?php echo form_error('quantity', '<p class="error">', '</p>'); ?></td>
            </tr>

            <tr>
                <td>Rent Price: </td>
                <td><input type="text" name="rentprice" placeholder="Enter your rent price"/></td>
                <td><?php echo form_error('rentprice', '<p class="error">', '</p>'); ?></td>
            </tr>
 <!--           <tr>
                <td>Car Image: </td>
                <td><input type="file" name="cimage" placeholder="Enter your car image"/></td>
                <td><?php /*echo form_error('cimage', '<p class="error">', '</p>'); */?></td>
            </tr>-->

            <tr>
                <td>&nbsp;</td>
                <td colspan="2"><input type="submit"  name="buttonCar" value="Add Car" /></td>
            </tr>
        </table>
    </form>
    <br />

    <!-- Label to display error message -->
    <label></label>

</center>
</body>
</html>