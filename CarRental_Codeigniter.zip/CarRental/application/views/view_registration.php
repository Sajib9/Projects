<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }

        .error
        {
            color: #CC0000;
        }
    </style>
</head>
<body>
<center>
    <h2>Car Rental BD</h2>
    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental">Home</a></td>
            <td><a href="http://localhost/CarRental/allcars">All Cars</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/registration">Registration</a></td>
            <td><a href="http://localhost/CarRental/login">Login</a></td>
        </tr>
    </table>

    <br />
    <br />

    <h3>REGISTRATION</h3>
    <form action="http://localhost/CarRental/registration" method="post">
        <table cellpadding="4" cellspacing="4">
            <tr>
                <td>FULLNAME: </td>
                <td><input type="text" name="fullname" placeholder="Enter your fullname" value="<?php echo set_value("fullname")?>"/></td>
                    <td><?php echo form_error('fullname', '<p class="error">', '</p>'); ?></td>
            </tr>

            <tr>
                <td>EMAIL: </td>
                <td><input type="text" name="email" placeholder="example@gmail.com" value="<?php echo set_value("email")?>" /></td>
                <td> <?php echo form_error('email', '<p class="error">', '</p>'); ?></td>
            </tr>

            <tr>
                <td>PASSWORD: </td>
                <td><input type="password" name="password" placeholder="Enter your Password"/></td>
                <td><?php echo form_error('password', '<p class="error">', '</p>'); ?></td>
            </tr>

            <tr>
                <td> CONFIRM PASSWORD: </td>
                <td><input type="password" name="confirmpassword" placeholder="Confirm your Password"/></td>
                <td> <?php echo form_error('confirmpassword', '<p class="error">', '</p>'); ?></td>
            </tr>

            <tr>
                <td>DISTRICT: </td>
                <td>
                    <select name="district">
                        <option value="Select your district">Select your district</option>
                        <option value="Dhaka">Dhaka</option>
                        <option value="khulna">khulna</option>
                        <option value="Rajshahi">Rajshahi</option>
                        <option value="Chittagong">Chittagong</option>
                        <option value="Sylhet">Sylhet</option>
                        <option value="Barishal">Barishal</option>
                        <option value="Rangpur">Rangpur</option>
                        <option value="Mymenshing">Mymenshing</option>
                    </select>
                </td>
                <td><?php echo form_error('district', '<p class="error">', '</p>'); ?></td>
            </tr>

            <tr>
                <td>HOUSE NO/VILLAGE: </td>
                <td><input type="text" name="houseno" placeholder="Enter your house no/village" <?php echo set_value("houseno")?>/></td>
                <td><?php echo form_error('houseno', '<p class="error">', '</p>'); ?></td>
            </tr>

            <tr>
                <td>PHONE NUMBER: </td>
                <td><input type="text" name="phone" placeholder="Enter your phone number" <?php echo set_value("phone")?>/></td>
                <td><?php echo form_error('phone', '<p class="error">', '</p>'); ?></td>
            </tr>

            <!--<tr>
                <td>CAPCHA: </td>
                <td><input type="text" name="capcha" placeholder="Enter your code here"/></td>
            </tr>-->

            <tr>
                <td>&nbsp;</td>
                <td colspan="2"><input type="submit"  name="submit" value="Registration" /></td>
            </tr>
        </table>
    </form>
    <br />

    <!-- Label to display error message -->
    <label></label>

</center>
</body>
</html>