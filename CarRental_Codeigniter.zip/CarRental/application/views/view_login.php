<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		body{
			font-family: Arial;
		}

	</style>
</head>
<body>
<center>
	<h2>Car Rental BD</h2>
	<table cellpadding="4" cellspacing="12">
		<tr>
			<td><a href="http://localhost/CarRental">Home</a></td>
			<td><a href="http://localhost/CarRental/allcars">All Cars</a></td>
			<td><a href="#"></a></td>
			<td><a href="#"></a></td>
			<td><a href="http://localhost/CarRental/registration">Registration</a></td>
			<td><a href="http://localhost/CarRental/login">Login</a></td>
		</tr>
	</table>

	<br />
	<br />

	<h3>LOGIN</h3>
	<form method="post">
		<table cellpadding="4" cellspacing="4">
			<tr>
				<td>EMAIL:</td>
				<td><input type="text" name="email"/></td>
			</tr>
			<tr>
				<td>PASSWORD:</td>
				<td><input type="password" name="password"/></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="checkbox" name="remember"/>remember me</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit"  name="buttonLogin" value="Login" /></td>
			</tr>
		</table>
	</form>

	<br />
	<br />

	<a href="http://localhost/CarRental/registration">Not Registered? Register Here..</a>

	<!-- Label to display error message -->
	<label></label>

</center>
</body>
</html>