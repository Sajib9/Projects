<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }

        .error
        {
            color: #CC0000;
        }
    </style>
	<script src="http://localhost/carRental/public/scripts/jquery-3.1.1.js" type="text/javascript"></script>
	<script src="http://localhost/carRental/public/scripts/search.js" type="text/javascript"></script>
</head>
<body>
<center>
	<h2>USER HOME</h2>
		<center>
    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental/Userhome/Uhome">All Cars</a></td>
            <td><a href="http://localhost/CarRental/Userhome/searchCar">Search Car</a></td>
            <td><a href="http://localhost/CarRental/Userhome/cart">Your Cart</a></td>
            <td><a href="http://localhost/CarRental/Userhome/profile">Edit Profile</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/dashboard/logout">Logout</a></td>
        </tr>
    </table>

    <br />
    <br />
    <h2>Car Info</h2>
		<center>
    <table border="1" cellpadding="4" cellspacing="4" width="50%">
        <thead>
        <tr>
            <td>Car Image</td>
            <td>Rent price(tk)</td>
            <td>Model</td>
            <td>Seat</td>
            <td>Laugage</td>
            <td>Air-Condition</td>
            <td>Quantity</td>
        </tr>
        </thead>
        <tbody>

        <tr>
            <td><img src="corolla.jpg" height="20%" width="80%"></td>

            <td><?php echo $rent_price; ?></td>
            <td><?php echo $model; ?></td>
            <td><?php echo $seat; ?></td>
            <td><?php echo $laugage; ?></td>
            <td><?php echo $condition; ?></td>
            <td><?php echo $quantity; ?></td>

        </tr>
        </tbody>
    </table>
	
	
	</center>


</center>
</body>
</html>