<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }

        .error
        {
            color: #CC0000;
        }
    </style>
</head>
<body>
<center>
    <h2>DashBoard(admin)</h2>
    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental/dashboard/dhome">DHome</a></td>
            <td><a href="http://localhost/CarRental/dashboard/booking">Booking</a></td>
            <td><a href="http://localhost/CarRental/dashboard/userlist">Userlist</a></td>
            <td><a href="http://localhost/CarRental/dashboard/report">Report</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/dashboard/logout">Logout</a></td>
        </tr>
    </table>

    <br />
    <br />

    <h3>USER LIST</h3>
    <table border="1" cellpadding="4" cellspacing="4">
        <thead>
        <tr>
            <th>USER NO.</th>
            <th>FULL NAME</th>
            <th>EMAIL</th>
            <th>DISTRICT</th>
            <th>HOUSENO</th>
            <th>PHONE</th>
            <th></th>
        </tr>
        </thead>
        <tbody>

        <?php foreach($userlist as $user) { ?>
            <tr>
                <td><?php echo $user['user_id']; ?></td>
                <td><?php echo $user['fullname']; ?></td>
                <td><?php echo $user['email']; ?></td>
                <td><?php echo $user['district']; ?></td>
                <td><?php echo $user['houseno']; ?></td>
                <td><?php echo $user['phone']; ?></td>

                <td><a href="#">Delete</a></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

</center>
</body>
</html>