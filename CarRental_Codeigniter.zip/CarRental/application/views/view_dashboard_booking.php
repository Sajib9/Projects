
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        body{
            font-family: Arial;
        }

        .error
        {
            color: #CC0000;
        }
    </style>
</head>
<body>
<center>
    <h2>DashBoard(admin)</h2>
    <table cellpadding="4" cellspacing="12">
        <tr>
            <td><a href="http://localhost/CarRental/dashboard/dhome">DHome</a></td>
            <td><a href="http://localhost/CarRental/dashboard/booking">Booking</a></td>
            <td><a href="http://localhost/CarRental/dashboard/userlist">Userlist</a></td>
            <td><a href="http://localhost/CarRental/dashboard/report">Report</a></td>
            <td><a href="#"></a></td>
            <td><a href="#"></a></td>
            <td><a href="http://localhost/CarRental/dashboard/logout">Logout</a></td>
        </tr>
    </table>

    <br />
    <br />

    <h1>BOOKING</h1>


</center>
</body>
</html>