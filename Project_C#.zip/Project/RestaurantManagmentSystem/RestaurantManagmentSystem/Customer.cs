﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RestaurantManagmentSystem.Entity;
using RestaurantManagmentSystem.BLL;
using System.Data.SqlClient;


namespace RestaurantManagmentSystem
{
    public partial class Customer : Form
    {
        public RestaurantInfo info = new RestaurantInfo();
        public RestaurantRepo rp = new RestaurantRepo();
        public Customer()
        {
            InitializeComponent();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            
            info.search = SearchField.Text;
            if (SearchField.Text == "")
            {
                MessageBox.Show("Enter Item name to search ");
            }
            else
            {
                DataTable dta = new DataTable();
                dta = rp.searchProduct(info);
                dataGridViewSearch.DataSource = dta;
            }
                              
        }

        private void dataGridViewSearch_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Customer_Load(object sender, EventArgs e)
        {
            //DataTable dt = new DataTable();
            //dt = rp.viewSearchProduct(info);
            //dataGridViewSearch.DataSource = dt;
        }

        private void AddToCartButton_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            int selectedRowIndex = dataGridViewSearch.Rows.GetRowCount(DataGridViewElementStates.Selected);
            if (selectedRowIndex > 0 & UnitField.Text != "")
            {
                info.itemname = dataGridViewSearch.SelectedRows[0].Cells[1].Value.ToString();
                info.quantity = Convert.ToInt32(dataGridViewSearch.SelectedRows[0].Cells[3].Value.ToString());
                info.unitPrice = Convert.ToInt32(dataGridViewSearch.SelectedRows[0].Cells[4].Value.ToString());
                info.unit = Convert.ToInt32(UnitField.Text);

                if (info.unit <= info.quantity)
                {
                    info.total = info.unit * info.unitPrice;
                    rp.insertToCart(info);
                   dt = rp.dgvCartItem(info);
                   dataGridViewCart.DataSource = dt;

                }
                else
                {
                    MessageBox.Show("Required Product Quantity is not available Or Quantity not entered");
                }

                UnitField.Clear();
            }
            else
            {
                MessageBox.Show("Select An Item First And also valid Quantity");
            }
        }

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            rp.removeFromCart(info);
            MessageBox.Show("---Removed---");
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = rp.refreshShopingCart(info);
            dataGridViewCart.DataSource = dt;
        }

        private void CheckOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            CheckOut checkout = new CheckOut();
            checkout.Show();
        }
    }
}
