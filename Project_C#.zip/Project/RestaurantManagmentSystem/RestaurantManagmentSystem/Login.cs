﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RestaurantManagmentSystem.BLL;
using RestaurantManagmentSystem.Entity;

namespace RestaurantManagmentSystem
{
    public partial class Login : Form
    {
        public RestaurantRepo rr = new RestaurantRepo();
        public RestaurantInfo ri = new RestaurantInfo();
        public string usertype;

        DataTable dt = new DataTable();

        public Login()
        {
            InitializeComponent();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string usrname=ri.username = UserNameField.Text;
            ri.password = PasswordField.Text;

            dt = rr.login(ri);
         
           
                if (dt.Rows.Count > 0)
                {
                    usertype = dt.Rows[0][7].ToString().Trim();
                    if (usertype == "A")
                    {
                        this.Hide();
                        Admin admin = new Admin();
                        admin.Show();


                    }
                    else
                    {
                        this.Hide();
                        Customer customer = new Customer();
                        customer.Show();


                    }
                }
                else
                {
                    MessageBox.Show("Invalid username or password");
                }

            }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 fm1 = new Form1();
            fm1.Show();
        }
        }
        
    }


