﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RestaurantManagmentSystem.BLL;
using RestaurantManagmentSystem.Entity;

namespace RestaurantManagmentSystem
{
    public partial class Form1 : Form
    {
        public RestaurantInfo info = new RestaurantInfo();
        public RestaurantRepo rp = new RestaurantRepo();
        string gender;

        public Form1()
        {
            InitializeComponent();
        }

        private void NameField_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void SignUp_Click(object sender, EventArgs e)
        {
            info.name = NameField.Text;
            if (RightButtonMale.Checked == true)
            {
                gender = "Male";
            }
            if (RightButtonFemale.Checked == true)
            {
                gender = "Female";
            }
            info.gender = gender;
            info.dob = Convert.ToDateTime(dateTimePicker.Value.ToShortDateString());
            info.address = AddressField.Text;
            info.username = UserNameField.Text;
            info.password = PasswordField.Text;

           int rows= rp.insertReg(info);
            try
            {
           if (rows > 0)
           {
               this.Hide();
               MessageBox.Show("Registration successfull");
           }
            }
           catch(Exception ex)
           {
               throw ex;

           }
        }

        }
    }

