﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RestaurantManagmentSystem.Entity;
using RestaurantManagmentSystem.BLL;
using System.Data.SqlClient;

namespace RestaurantManagmentSystem
{
    public partial class Admin : Form
    {
        public RestaurantInfo info = new RestaurantInfo();
        public RestaurantRepo rp = new RestaurantRepo();
      
        public Admin()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            info.id = Convert.ToInt32(IdField.Text);
            info.productname = ProductNameField.Text;
            info.unitprice = Convert.ToInt32(UnitPriceField.Text);
            info.quantity = Convert.ToInt32(QuantityField.Text);
            info.category = comboBox1.Text;

            try
            {
                if (IdField.Text != "" & ProductNameField.Text != "" & UnitPriceField.Text != "" & QuantityField.Text != "" & comboBox1.Text != "")
                {
                    rp.insertProduct(info);

                    MessageBox.Show("Product Added");
    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Message",MessageBoxButtons.OK,MessageBoxIcon.Error);

            }
            IdField.Clear();
            ProductNameField.Clear();
            UnitPriceField.Clear();
            QuantityField.Clear();
            comboBox1.SelectedIndex = -1;

        }

       
        private void Admin_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = rp.viewProduct(info);
            dataGridView1.DataSource = dt;

           
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = rp.refreshProduct(info);
            dataGridView1.DataSource = dt;
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            info.id = Convert.ToInt32(IdField.Text);
            info.productname = ProductNameField.Text;
            info.unitprice = Convert.ToInt32(UnitPriceField.Text);
            info.quantity = Convert.ToInt32(QuantityField.Text);
            info.category = comboBox1.Text;
             rp.editProduct(info);
             MessageBox.Show("Product Edited");


             IdField.Clear();
             ProductNameField.Clear();
             UnitPriceField.Clear();
             QuantityField.Clear();
             comboBox1.SelectedIndex = -1;

        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            IdField.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            ProductNameField.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            comboBox1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            QuantityField.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            UnitPriceField.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            info.id = Convert.ToInt32(IdField.Text);
            info.productname = ProductNameField.Text;
            info.category = comboBox1.Text;
            info.quantity = Convert.ToInt32(QuantityField.Text);
            info.unitprice = Convert.ToInt32(UnitPriceField.Text);
        
            rp.deleteProduct(info);
            MessageBox.Show(" Product Deleted ");

            IdField.Clear();
            ProductNameField.Clear();
            UnitPriceField.Clear();
            QuantityField.Clear();
            comboBox1.SelectedIndex = -1;
        }

        
    }
}

