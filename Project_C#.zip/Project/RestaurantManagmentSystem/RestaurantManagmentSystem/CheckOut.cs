﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using RestaurantManagmentSystem.Entity;
using RestaurantManagmentSystem.BLL;
using System.Data.SqlClient;

namespace RestaurantManagmentSystem
{
    public partial class CheckOut : Form
    {
        public RestaurantInfo info = new RestaurantInfo();
        public RestaurantRepo rp = new RestaurantRepo();
        public CheckOut()
        {
            InitializeComponent();
        }

        private void CheckOut_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = rp.viewCheckOutItemList(info);
            dataGridViewCheckOut.DataSource = dt;

        }
    }
}
