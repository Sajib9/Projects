﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RestaurantmanagmentSystem.DAL;
using RestaurantManagmentSystem.Entity;
using System.Data;
using System.Data.SqlClient;
using RestaurantManagment.BLL;





namespace RestaurantManagmentSystem.BLL
{
    public class RestaurantRepo
    {
        public RestaurantData rd = new RestaurantData();
        public RestaurantInfo ri = new RestaurantInfo();
       
       
        //here we declare the queries and db operations need for the application

        public int insertReg(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Registration VALUES ('"+ri.name+"','"+ri.gender+"','"+ri.dob+"','"+ri.address+"','"+ri.username+"','"+ri.password+"')";
            return rd.ExeNonQuery(cmd);
            
        }

        public DataTable login(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Registration  where UserName='"+ri.username+"'and Password='"+ri.password+"' ";

            return rd.ExeReader(cmd);
           
        }

        public int insertProduct(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Product VALUES ('"+ri.id+"','"+ri.productname+"','"+ri.category+"','"+ri.quantity+"','"+ri.unitprice+"') ";
            return rd.ExeNonQuery(cmd);
        }

        public DataTable viewProduct(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Product ";


            return rd.ExeReader(cmd);


        }

         public DataTable refreshProduct(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Product ";


            return rd.ExeReader(cmd);
        }

        public int editProduct(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE Product SET ProductName='"+ri.productname+"',Category='"+ri.category+"',Quantity='"+ri.quantity+"',UnitPrice='"+ri.unitprice+"' where Id='"+ri.id+"' ";
          
            return rd.ExeNonQuery(cmd); 
        }

        public int deleteProduct(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE FROM Product where Id='" + ri.id + "' ";

            return rd.ExeNonQuery(cmd);
        }

        public DataTable searchProduct(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Product where ProductName='"+ri.search+"' ";

            return rd.ExeReader(cmd);
        }



        public int insertToCart(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into ShopingCart VALUES ('" + ri.itemname + "','" + ri.unitPrice + "','" + ri.unit + "','" + ri.total + "') ";
            return rd.ExeNonQuery(cmd);
        }

        public DataTable dgvCartItem(RestaurantInfo info)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from ShopingCart ";


            return rd.ExeReader(cmd);
        }

        public int removeFromCart(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE FROM ShopingCart where ItemName='" + ri.itemname + "' ";

            return rd.ExeNonQuery(cmd);
        }

        public DataTable refreshShopingCart(RestaurantInfo ri)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from ShopingCart ";


            return rd.ExeReader(cmd);
        }

        public DataTable viewCheckOutItemList(RestaurantInfo info)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from ShopingCart ";


            return rd.ExeReader(cmd);
        }
    }
}
