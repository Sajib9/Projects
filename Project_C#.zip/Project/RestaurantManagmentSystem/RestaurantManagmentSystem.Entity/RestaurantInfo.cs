﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RestaurantManagmentSystem.Entity
{
    public class RestaurantInfo
    {
        //here we declare the variables used in the application
        public int id { get; set; }
        public string name { get; set; }
        public string gender { get; set; }
        public DateTime dob { get; set; }
        public string address { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string productname { get; set; }
        public string category { get; set; }
        public int unitprice { get; set; }
        public int quantity { get; set; }
        public string search { get; set; }
        public string itemname { get; set; }
        public int unitPrice { get; set; }
        public int unit { get; set; }
        public int total { get; set; }


    }
}
